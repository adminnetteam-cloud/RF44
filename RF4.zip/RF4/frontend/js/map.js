const map = L.map("map").setView([0,0],2);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);
map.on("click", e =>
  coords.value = `${e.latlng.lat.toFixed(2)}:${e.latlng.lng.toFixed(2)}`
);
