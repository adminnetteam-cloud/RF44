const mongoose = require("mongoose");

module.exports = mongoose.model("Spot", new mongoose.Schema({
  map: String,
  fish: String,
  coords: String,
  bait: String,
  author: String,
  likes: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now }
}));
