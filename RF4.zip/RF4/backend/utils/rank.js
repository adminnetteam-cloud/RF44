module.exports = likes => {
  if (likes >= 60) return "Master";
  if (likes >= 30) return "Expert";
  if (likes >= 15) return "Fisherman";
  if (likes >= 5) return "Angler";
  return "Rookie";
};
