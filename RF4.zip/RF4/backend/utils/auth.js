const router = require("express").Router();
const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

router.post("/register", async (req, res) => {
  req.body.password = await bcrypt.hash(req.body.password, 10);
  res.json(await User.create(req.body));
});

router.post("/login", async (req, res) => {
  const user = await User.findOne({ email: req.body.email });
  if (!user) return res.sendStatus(400);
  const ok = await bcrypt.compare(req.body.password, user.password);
  if (!ok) return res.sendStatus(400);

  res.json({
    token: jwt.sign(
      { id: user._id, username: user.username, role: user.role },
      process.env.JWT_SECRET
    )
  });
});

module.exports = router;
