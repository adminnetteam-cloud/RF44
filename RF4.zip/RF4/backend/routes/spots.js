const router = require("express").Router();
const Spot = require("../models/Spot");
const User = require("../models/User");
const auth = require("../middleware/authMiddleware");

router.get("/", async (req, res) => {
  const spots = await Spot.find();
  res.json(spots.filter(s =>
    Date.now() - s.createdAt < 6 * 60 * 60 * 1000
  ));
});

router.post("/", auth, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (user.banned) return res.sendStatus(403);
  res.json(await Spot.create({ ...req.body, author: req.user.username }));
});

router.post("/:id/like", async (req, res) => {
  await Spot.findByIdAndUpdate(req.params.id, { $inc: { likes: 1 } });
  res.json({ ok: true });
});

module.exports = router;
