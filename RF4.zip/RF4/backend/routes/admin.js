const router = require("express").Router();
const User = require("../models/User");
const Spot = require("../models/Spot");
const auth = require("../middleware/authMiddleware");
const admin = require("../middleware/adminMiddleware");
const rank = require("../utils/rank");

router.get("/users", auth, admin, async (req, res) => {
  const users = await User.find();
  const spots = await Spot.find();

  res.json(users.map(u => {
    const likes = spots
      .filter(s => s.author === u.username)
      .reduce((a, b) => a + b.likes, 0);
    return { ...u._doc, likes, rank: rank(likes) };
  }));
});

router.post("/ban/:id", auth, admin, async (req, res) => {
  await User.findByIdAndUpdate(req.params.id, { banned: true });
  res.json({ ok: true });
});

module.exports = router;
